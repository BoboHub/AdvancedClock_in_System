# USAGE
# python unenroll.py --id S1901 --conf config/config.json
# Student: Boris Figeczky x15048179
# Date: 10/05/2020
# Resource2: https://www.pyimagesearch.com/raspberry-pi-for-computer-vision/ (Hacker Bundle, by Adrian Rosebrock, PHd)

# import the necessary packages
from pyimagesearch.utils import Conf
from tinydb import TinyDB
from tinydb import where
import argparse
import shutil
import os

# construct the argument parser and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-i", "--id", required=True, 
    help="Unique employee ID of the employee")
ap.add_argument("-c", "--conf", required=True, 
    help="Path to the input configuration file")
args = vars(ap.parse_args())

# load the configuration file
conf = Conf(args["conf"])

# initialize the database and employee table objects
db = TinyDB(conf["db_path"])
employeeTable = db.table("employee")

# retrieve the employee document from the database, mark the employee 
# as unenrolled, and write back the document to the database
employee = employeeTable.search(where(args["id"]))
employee[0][args["id"]][1] = "unenrolled"
employeeTable.write_back(employee)

# delete the employee's data from the dataset
shutil.rmtree(os.path.join(conf["dataset_path"], conf["class"],
    args["id"]))
print("[INFO] Please extract the embeddings and re-train the face" \
    " recognition model...")

# close the database
db.close()