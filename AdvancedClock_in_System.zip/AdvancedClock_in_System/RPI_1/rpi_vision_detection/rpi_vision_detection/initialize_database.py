# USAGE
# python initialize_database.py --conf config/config.json

# Student: Boris Figeczky x15048179
# Date: 10/05/2020
# Resource2: https://www.pyimagesearch.com/raspberry-pi-for-computer-vision/ (Hacker Bundle, by Adrian Rosebrock, PHd)

# import the necessary packages
from pyimagesearch.utils import Conf
from tinydb import TinyDB
import argparse

# construct the argument parser and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-c", "--conf", required=True, 
	help="Path to the input configuration file")
args = vars(ap.parse_args())

# load the configuration file
conf = Conf(args["conf"])

# initialize the database
db = TinyDB(conf["db_path"])

# insert the details regarding the class
print("[INFO] initializing the database...")
db.insert({"class": conf["class"]})
print("[INFO] database initialized...")

# close the database
db.close()